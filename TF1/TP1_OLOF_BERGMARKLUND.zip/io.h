#ifndef __IO__
#define __IO__

#include "Student.h"
#include "Class.h"

void PrintStudent(const Student &s);
void PrintClass(const Classe &c);
Student * EnterStudent();
Classe * EnterClass();

#endif
